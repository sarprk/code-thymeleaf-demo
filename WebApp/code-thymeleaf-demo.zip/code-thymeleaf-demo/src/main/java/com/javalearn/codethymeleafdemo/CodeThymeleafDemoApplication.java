package com.javalearn.codethymeleafdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodeThymeleafDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodeThymeleafDemoApplication.class, args);
	}

}
